# Principal architect analysis

The current client-side Team KPI hotfix cannot be made reliable by adding more browser queries. Its first users query selects a nonexistent `role` column and all Supabase errors are ignored, so a schema or RLS failure appears as an empty report.

The repair uses one authorized database function and one browser request. The function directly aggregates confirmed domain records within the selected India business day and includes active users with zero work. Realtime events trigger a debounced recomputation; they never mutate counters in the browser.

Important durability corrections included in the patch:

- Role labels come from capability assignments.
- Calls exclude synthetic pipeline gate logs.
- Resolved queries are credited to the resolver.
- Mapping requester and completer are preserved separately.
- Normal tasks use completion-history events with a legacy fallback.
- Spreadsheet-allocated targets are included in Tasks done.
- Historical snapshot rows remain, but obsolete snapshot triggers and active snapshot sync are retired.
- Response totals are validated against every returned row before rendering.
- Errors remain visible instead of becoming an empty table.
