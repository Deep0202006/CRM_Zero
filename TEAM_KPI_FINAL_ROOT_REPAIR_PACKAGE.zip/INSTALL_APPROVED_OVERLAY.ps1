param(
  [Parameter(Mandatory = $false)]
  [string]$ProjectRoot = (Get-Location).Path
)

$ErrorActionPreference = "Stop"
$PackageRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$ManifestPath = Join-Path $PackageRoot "PATCH_MANIFEST.json"
$OverlayRoot = Join-Path $PackageRoot "project-overlay"

if (-not (Test-Path (Join-Path $ProjectRoot "package.json"))) {
  throw "ProjectRoot does not look like the ZeroData repository: $ProjectRoot"
}
if (-not (Test-Path $ManifestPath)) { throw "Missing PATCH_MANIFEST.json" }
if (-not (Test-Path $OverlayRoot)) { throw "Missing project-overlay folder" }

$manifest = Get-Content $ManifestPath -Raw | ConvertFrom-Json
$timestamp = Get-Date -Format "yyyyMMdd-HHmmss"
$backupRoot = Join-Path (Split-Path $ProjectRoot -Parent) "CRM_Zero_team_kpi_backup_$timestamp"
New-Item -ItemType Directory -Force -Path $backupRoot | Out-Null

$backupEntries = @()

foreach ($entry in $manifest.files) {
  $relativePath = [string]$entry.path
  if ($relativePath.Contains("..")) { throw "Unsafe manifest path: $relativePath" }

  $sourcePath = Join-Path $OverlayRoot $relativePath
  $destinationPath = Join-Path $ProjectRoot $relativePath
  if (-not (Test-Path $sourcePath)) { throw "Missing approved source file: $relativePath" }

  $actualHash = (Get-FileHash $sourcePath -Algorithm SHA256).Hash.ToLowerInvariant()
  if ($actualHash -ne ([string]$entry.sha256).ToLowerInvariant()) {
    throw "Package hash mismatch: $relativePath"
  }

  $existed = Test-Path $destinationPath
  if ($existed) {
    $backupPath = Join-Path $backupRoot $relativePath
    New-Item -ItemType Directory -Force -Path (Split-Path $backupPath -Parent) | Out-Null
    Copy-Item $destinationPath $backupPath -Force
  }

  $backupEntries += [pscustomobject]@{
    path = $relativePath
    existedBefore = $existed
  }
}

$backupManifest = [pscustomobject]@{
  projectRoot = $ProjectRoot
  createdAt = (Get-Date).ToString("o")
  files = $backupEntries
}
$backupManifest | ConvertTo-Json -Depth 5 | Set-Content (Join-Path $backupRoot "backup-manifest.json") -Encoding UTF8

foreach ($entry in $manifest.files) {
  $relativePath = [string]$entry.path
  $sourcePath = Join-Path $OverlayRoot $relativePath
  $destinationPath = Join-Path $ProjectRoot $relativePath
  New-Item -ItemType Directory -Force -Path (Split-Path $destinationPath -Parent) | Out-Null
  Copy-Item $sourcePath $destinationPath -Force

  $installedHash = (Get-FileHash $destinationPath -Algorithm SHA256).Hash.ToLowerInvariant()
  if ($installedHash -ne ([string]$entry.sha256).ToLowerInvariant()) {
    throw "Installed file verification failed: $relativePath"
  }
}

Write-Host "APPROVED TEAM KPI OVERLAY INSTALLED" -ForegroundColor Green
Write-Host "Files installed: $($manifest.files.Count)"
Write-Host "Rollback backup: $backupRoot"
Write-Host "No environment file, dependency folder, or unrelated source path was touched."
