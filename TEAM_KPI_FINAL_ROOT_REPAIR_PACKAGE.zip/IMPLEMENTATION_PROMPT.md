# Approved ZeroData Team KPI Root Repair — Mechanical Installation

You are acting only as a release-integration engineer.

The Principal Software Architect has already completed the code and database design.

Do not redesign, reinterpret, simplify, refactor, rewrite, or independently “improve” the approved files.

Do not create another Team KPI implementation, RPC, migration, ledger, fallback, or aggregation path.

Do not modify any file outside `PATCH_MANIFEST.json`.

## Package

The extracted package contains:

- `project-overlay/`
- `PATCH_MANIFEST.json`
- `INSTALL_APPROVED_OVERLAY.ps1`
- `ROLLBACK_APPROVED_OVERLAY.ps1`
- `MANUAL_SUPABASE/`
- `ROOT_CAUSE_ANALYSIS.md`
- `DEPLOYMENT_RUNBOOK.md`
- `STATIC_VERIFICATION.txt`

## Absolute restrictions

Do not:

- Read or print `.env` files.
- Display credentials.
- Use Supabase CLI.
- Use Docker.
- Run database passwords in commands.
- Apply database SQL yourself.
- Push or merge `main`.
- Change the Team KPI page design.
- Change login, pipeline, visits, attendance, mappings, support, tasks, My Day, global CSS, or design tokens.
- Add dependencies.
- Delete retained business data.
- Change migrations 001–028.
- Disable lint, TypeScript, tests, RLS, or error handling.
- Use `@ts-ignore` or unexplained `any`.

## 1. Create a release branch and checkpoint

From the existing project root:

```powershell
git status --short
git switch -c fix/team-kpi-final-root-repair
git add -A
git commit -m "chore: checkpoint before final Team KPI root repair"
```

When the branch already exists, stop and report it rather than overwriting history.

## 2. Install the exact approved overlay

Run the installer from the extracted package:

```powershell
powershell -ExecutionPolicy Bypass -File "<EXTRACTED_PACKAGE_PATH>\INSTALL_APPROVED_OVERLAY.ps1" -ProjectRoot "<CRM_PROJECT_ROOT>"
```

Do not copy the complete repository.

Do not use `/MIR` or `/PURGE`.

Do not manually merge the files.

The installer:

- Backs up every replaced file outside the repository.
- Verifies each source hash.
- Copies exactly 19 approved paths.
- Verifies every installed hash.
- Leaves environment files and unrelated code untouched.

Record the printed rollback-backup path.

## 3. Verify the change boundary

Run:

```powershell
git status --short
git diff --name-only
git diff --stat
git diff --check
```

Every modified or added application path must appear in `PATCH_MANIFEST.json`.

Restore any unrelated change before continuing.

Do not remove intentional local work that existed before this branch checkpoint.

## 4. Run complete repository checks

Run separately:

```powershell
npm ci
npm run lint
npm test -- --runInBand
npm run build
git diff --check
```

For every command record:

- Command.
- Exit code.
- Pass/fail.
- Test count.
- Exact error when failed.

Do not proceed after a failure.

Fix nothing by redesigning or changing architecture. When a conflict or test failure concerns an approved file, report the exact text and stop.

## 5. Confirm critical installed contracts

Run read-only searches:

```powershell
Select-String -Path src\app\api\team-kpi\route.ts -Pattern "get_team_kpi_daily_v4"
Select-String -Path src\app\manager\kpi\page.tsx -Pattern "call_logs|client_queries|mapping_requests|tasks|allocated_targets"
Select-String -Path src\app\call-logs\page.tsx -Pattern "client_username|client_name|parseCallClientReference"
Select-String -Path src\lib\db.ts -Pattern "prepareSyncPayload|activeSyncQueueRun|legacy-repair:call_logs"
Select-String -Path supabase\migrations\029_team_kpi_source_sync_repair.sql -Pattern "get_team_kpi_daily_v4|ALTER COLUMN lead_id DROP NOT NULL"
```

Confirm:

- Team KPI UI still uses `/api/team-kpi`.
- Browser does not aggregate raw KPI records.
- API uses v4 first.
- Raw fallback requires a server-only service client.
- Call Activity no longer stores Excel identity in a UUID field.
- Sync queue repairs and retries identifiable legacy records.
- Pull-down does not repopulate remote tables from browser cache.
- Migration 029 is the only new migration.

## 6. Commit repository implementation

When all local checks pass:

```powershell
git add -A
git commit -m "fix: make Team KPI source data live and durable"
```

Do not push `main`.

Pushing the feature branch for a Vercel Preview is allowed only after the operator confirms the manual Supabase step is ready.

## 7. Stop for manual Supabase execution

Do not run the SQL yourself.

Tell the operator to run these in Supabase Dashboard → SQL Editor:

1. `MANUAL_SUPABASE/01_PRECHECK_READ_ONLY.sql`
2. `MANUAL_SUPABASE/02_APPLY_TEAM_KPI_029.sql` once
3. `MANUAL_SUPABASE/03_VERIFY_READ_ONLY.sql`

The operator must stop if the precheck reports any required core table or column as `MISSING`.

The apply script must not be rerun blindly after an error.

## 8. Vercel Preview after manual SQL

After the operator confirms migration 029 and verification succeeded:

```powershell
git push -u origin fix/team-kpi-final-root-repair
```

Do not merge `main`.

Find the Vercel Preview deployment for the feature branch and follow `DEPLOYMENT_RUNBOOK.md`.

## 9. Required final report

Return exactly:

### Status

- LOCAL IMPLEMENTATION VERIFIED
- BLOCKED

### Change boundary

- Approved files installed: 19/19
- Unapproved files changed: list or None
- Existing frontend design changed: No
- Other CRM workflows intentionally redesigned: No

### Local checks

- npm ci
- lint
- tests
- production build
- git diff check

Include exit codes.

### Critical contracts

- RPC v4 frontend call
- Server-only fallback
- Excel call identity repair
- Legacy queue repair
- Remote-row verification
- RLS-empty recovery disabled
- India date handling
- Realtime source refresh

### Manual database step

- Applied by this task: No
- Precheck path
- Apply path
- Verify path

### Git

- Branch
- Checkpoint commit
- Implementation commit
- Final `git status --short`

### Remaining blocker

Include exact error and reproduction, or `None — awaiting manual Supabase execution and Preview smoke test`.

Do not claim that live Team KPI is verified until the manual SQL and Vercel Preview smoke tests pass.
