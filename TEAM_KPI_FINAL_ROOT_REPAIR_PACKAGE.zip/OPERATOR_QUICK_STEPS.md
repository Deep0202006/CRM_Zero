# Operator Quick Steps

1. Put `TEAM_KPI_FINAL_ROOT_REPAIR_PACKAGE.zip` in the CRM project folder.
2. Ask the local LLM to extract it to a temporary folder and follow `IMPLEMENTATION_PROMPT.md` exactly.
3. The local LLM must run the approved installer; it must not write code.
4. Confirm `npm ci`, lint, tests, build, and diff checks pass.
5. In Supabase SQL Editor run:
   1. `01_PRECHECK_READ_ONLY.sql`
   2. `02_APPLY_TEAM_KPI_029.sql` once
   3. `03_VERIFY_READ_ONLY.sql`
6. Deploy the feature branch to Vercel Preview.
7. Test Team KPI with admin and ordinary users.
8. Ask every team member to open the updated CRM once while online so recoverable legacy local calls/tasks can synchronize.
9. Verify today and at least three retained historical dates.
10. Merge to production only after Preview acceptance.

Do not rerun migration 029 after success. Do not apply any older repair ZIP after this package.
