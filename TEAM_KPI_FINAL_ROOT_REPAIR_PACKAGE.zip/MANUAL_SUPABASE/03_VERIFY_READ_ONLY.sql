-- ZeroData Team KPI — migration 029 verification
-- READ ONLY. Run after 02_APPLY_TEAM_KPI_029.sql succeeds.

SELECT
  to_regprocedure('public.get_team_kpi_daily_v4(date)') IS NOT NULL AS rpc_exists,
  has_function_privilege('authenticated', 'public.get_team_kpi_daily_v4(date)', 'EXECUTE') AS authenticated_execute,
  has_function_privilege('anon', 'public.get_team_kpi_daily_v4(date)', 'EXECUTE') AS anon_execute,
  has_function_privilege('public', 'public.get_team_kpi_daily_v4(date)', 'EXECUTE') AS public_execute;

SELECT pg_get_functiondef('public.get_team_kpi_daily_v4(date)'::regprocedure) AS function_definition;

SELECT
  column_name,
  data_type,
  is_nullable
FROM information_schema.columns
WHERE table_schema = 'public'
  AND table_name = 'call_logs'
  AND column_name IN ('lead_id', 'client_username', 'client_name')
ORDER BY column_name;

SELECT
  policyname,
  cmd,
  roles,
  qual,
  with_check
FROM pg_policies
WHERE schemaname = 'public' AND tablename = 'call_logs'
ORDER BY policyname;

SELECT
  indexname,
  indexdef
FROM pg_indexes
WHERE schemaname = 'public'
  AND indexname IN (
    'idx_call_logs_kpi_user_timestamp',
    'idx_client_queries_kpi_resolver_time',
    'idx_mapping_requests_kpi_mapper_time',
    'idx_tasks_kpi_assignee_completion',
    'idx_task_history_kpi_actor_time',
    'idx_allocated_targets_kpi_user_time'
  )
ORDER BY indexname;

SELECT
  expected.tablename,
  CASE WHEN publication_table.tablename IS NULL THEN 'MISSING' ELSE 'PRESENT' END AS realtime_status
FROM (VALUES
  ('users'), ('user_capabilities'), ('call_logs'), ('client_queries'),
  ('mapping_requests'), ('mappings'), ('tasks'), ('task_status_history'),
  ('allocated_targets')
) AS expected(tablename)
LEFT JOIN pg_publication_tables publication_table
  ON publication_table.pubname = 'supabase_realtime'
 AND publication_table.schemaname = 'public'
 AND publication_table.tablename = expected.tablename
ORDER BY expected.tablename;

-- Source records by India business date. These counts should become visible on
-- Team KPI after the application deployment and successful employee sync.
WITH recent_dates AS (
  SELECT generate_series(
    (now() AT TIME ZONE 'Asia/Kolkata')::date - 13,
    (now() AT TIME ZONE 'Asia/Kolkata')::date,
    interval '1 day'
  )::date AS business_date
), calls AS (
  SELECT (timestamp AT TIME ZONE 'Asia/Kolkata')::date AS business_date, count(*) AS value
  FROM public.call_logs
  WHERE user_id IS NOT NULL
    AND COALESCE(outcome, '') !~* '^\s*(\[.*\]\s*(→|->)|pipeline\s+stage)'
  GROUP BY 1
), queries AS (
  SELECT (resolved_at AT TIME ZONE 'Asia/Kolkata')::date AS business_date, count(*) AS value
  FROM public.client_queries
  WHERE lower(COALESCE(problem_status, '')) = 'resolved' AND resolved_at IS NOT NULL
  GROUP BY 1
), mappings AS (
  SELECT (completed_at AT TIME ZONE 'Asia/Kolkata')::date AS business_date, count(*) AS value
  FROM public.mapping_requests
  WHERE lower(COALESCE(status, '')) IN ('completed', 'resolved') AND completed_at IS NOT NULL
  GROUP BY 1
), task_history AS (
  SELECT (changed_at AT TIME ZONE 'Asia/Kolkata')::date AS business_date, count(DISTINCT task_id) AS value
  FROM public.task_status_history
  WHERE lower(COALESCE(new_status, '')) = 'completed'
  GROUP BY 1
), targets AS (
  SELECT (completed_at AT TIME ZONE 'Asia/Kolkata')::date AS business_date, count(*) AS value
  FROM public.allocated_targets
  WHERE is_completed = true AND completed_at IS NOT NULL
  GROUP BY 1
)
SELECT
  recent_dates.business_date,
  COALESCE(calls.value, 0) AS calls,
  COALESCE(queries.value, 0) AS client_queries,
  COALESCE(mappings.value, 0) AS mappings,
  COALESCE(task_history.value, 0) + COALESCE(targets.value, 0) AS tasks
FROM recent_dates
LEFT JOIN calls USING (business_date)
LEFT JOIN queries USING (business_date)
LEFT JOIN mappings USING (business_date)
LEFT JOIN task_history USING (business_date)
LEFT JOIN targets USING (business_date)
ORDER BY recent_dates.business_date DESC;


SELECT
  event_object_table AS source_table,
  trigger_name
FROM information_schema.triggers
WHERE event_object_schema = 'public'
  AND trigger_name IN (
    'team_kpi_call_log_event', 'team_kpi_call_log_delete_event',
    'team_kpi_client_query_event', 'team_kpi_client_query_delete_event',
    'team_kpi_mapping_request_event', 'team_kpi_mapping_request_delete_event',
    'team_kpi_task_history_event', 'team_kpi_task_history_delete_event',
    'team_kpi_task_event', 'team_kpi_task_delete_event',
    'team_kpi_allocated_target_event', 'team_kpi_allocated_target_delete_event'
  )
ORDER BY source_table, trigger_name;
-- Expected: zero rows. Historical ledger data is retained, but capture triggers are retired.

SELECT
  CASE WHEN EXISTS (
    SELECT 1 FROM pg_publication_tables
    WHERE pubname = 'supabase_realtime'
      AND schemaname = 'public'
      AND tablename = 'team_work_events'
  ) THEN 'UNEXPECTED_PRESENT' ELSE 'ABSENT' END AS legacy_ledger_realtime_status;
-- Expected: ABSENT. Team KPI refreshes from authoritative source tables.

-- SQL Editor does not provide the normal application auth.uid() context, so do
-- not treat a direct RPC call here as the authorization test. Test the RPC from
-- /manager/kpi with one admin and one ordinary user.
-- If the deployed app reports PGRST202/schema-cache after a successful apply,
-- run this separately once:
-- NOTIFY pgrst, 'reload schema';
