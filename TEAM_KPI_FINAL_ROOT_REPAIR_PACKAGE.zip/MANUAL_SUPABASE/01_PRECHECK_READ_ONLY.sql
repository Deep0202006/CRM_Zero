-- ZeroData Team KPI — migration 029 precheck
-- READ ONLY. Run in the Supabase SQL Editor for the project used by Vercel.

SELECT current_database() AS database_name, current_user AS sql_editor_role, now() AS checked_at;

WITH required_tables(table_name) AS (
  VALUES
    ('users'), ('capabilities'), ('user_capabilities'), ('call_logs'),
    ('client_queries'), ('mapping_requests'), ('tasks'),
    ('task_status_history'), ('allocated_targets')
)
SELECT
  required_tables.table_name,
  CASE WHEN to_regclass(format('public.%I', required_tables.table_name)) IS NULL
    THEN 'MISSING' ELSE 'PRESENT' END AS status
FROM required_tables
ORDER BY required_tables.table_name;

WITH required_columns(table_name, column_name) AS (
  VALUES
    ('users','user_id'), ('users','name'), ('users','is_active'),
    ('user_capabilities','user_id'), ('user_capabilities','capability_code'),
    ('call_logs','log_id'), ('call_logs','user_id'), ('call_logs','lead_id'),
    ('call_logs','timestamp'), ('call_logs','outcome'),
    ('client_queries','query_id'), ('client_queries','assigned_to'),
    ('client_queries','problem_status'), ('client_queries','resolved_at'),
    ('mapping_requests','request_id'), ('mapping_requests','mapped_by'),
    ('mapping_requests','status'), ('mapping_requests','completed_at'),
    ('tasks','task_id'), ('tasks','assigned_to'), ('tasks','status'), ('tasks','completed_at'),
    ('task_status_history','task_id'), ('task_status_history','changed_by'),
    ('task_status_history','new_status'), ('task_status_history','changed_at'),
    ('allocated_targets','target_id'), ('allocated_targets','assigned_to_user_id'),
    ('allocated_targets','is_completed'), ('allocated_targets','completed_at')
)
SELECT
  required_columns.table_name,
  required_columns.column_name,
  COALESCE(columns.data_type, 'MISSING') AS data_type,
  CASE WHEN columns.column_name IS NULL THEN 'MISSING' ELSE 'PRESENT' END AS status
FROM required_columns
LEFT JOIN information_schema.columns columns
  ON columns.table_schema = 'public'
 AND columns.table_name = required_columns.table_name
 AND columns.column_name = required_columns.column_name
ORDER BY required_columns.table_name, required_columns.column_name;

SELECT
  routine.routine_name,
  routine.data_type AS return_type,
  routine.security_type
FROM information_schema.routines routine
WHERE routine.specific_schema = 'public'
  AND routine.routine_name IN (
    'get_team_kpi_daily',
    'get_team_kpi_daily_v3',
    'get_team_kpi_daily_v4'
  )
ORDER BY routine.routine_name;

SELECT
  COUNT(*) FILTER (WHERE lower(COALESCE(is_active::text, 'false')) IN ('1', 'true', 't')) AS active_users,
  COUNT(*) FILTER (WHERE lower(COALESCE(is_active::text, 'false')) NOT IN ('1', 'true', 't')) AS inactive_users
FROM public.users;

SELECT
  column_name,
  data_type,
  udt_name,
  is_nullable
FROM information_schema.columns
WHERE table_schema = 'public'
  AND table_name = 'users'
  AND column_name = 'is_active';

SELECT
  event_object_table AS source_table,
  trigger_name
FROM information_schema.triggers
WHERE event_object_schema = 'public'
  AND trigger_name LIKE 'team_kpi_%_event'
ORDER BY source_table, trigger_name;

SELECT
  CASE WHEN EXISTS (
    SELECT 1 FROM pg_publication_tables
    WHERE pubname = 'supabase_realtime'
      AND schemaname = 'public'
      AND tablename = 'team_work_events'
  ) THEN 'PRESENT' ELSE 'ABSENT' END AS legacy_ledger_realtime_status;

SELECT
  (call_log.timestamp AT TIME ZONE 'Asia/Kolkata')::date AS business_date,
  COUNT(*) FILTER (
    WHERE call_log.user_id IS NOT NULL
      AND COALESCE(call_log.outcome, '') !~* '^\s*(\[.*\]\s*(→|->)|pipeline\s+stage)'
  ) AS real_calls
FROM public.call_logs call_log
WHERE call_log.timestamp >= now() - interval '30 days'
GROUP BY 1
ORDER BY 1 DESC;

SELECT
  (query_row.resolved_at AT TIME ZONE 'Asia/Kolkata')::date AS business_date,
  COUNT(*) AS resolved_queries
FROM public.client_queries query_row
WHERE lower(COALESCE(query_row.problem_status, '')) = 'resolved'
  AND query_row.resolved_at IS NOT NULL
  AND query_row.resolved_at >= now() - interval '30 days'
GROUP BY 1
ORDER BY 1 DESC;

SELECT
  (mapping_row.completed_at AT TIME ZONE 'Asia/Kolkata')::date AS business_date,
  COUNT(*) AS completed_mappings
FROM public.mapping_requests mapping_row
WHERE lower(COALESCE(mapping_row.status, '')) IN ('completed', 'resolved')
  AND mapping_row.completed_at IS NOT NULL
  AND mapping_row.completed_at >= now() - interval '30 days'
GROUP BY 1
ORDER BY 1 DESC;

SELECT
  (history_row.changed_at AT TIME ZONE 'Asia/Kolkata')::date AS business_date,
  COUNT(DISTINCT history_row.task_id) AS task_completions
FROM public.task_status_history history_row
WHERE lower(COALESCE(history_row.new_status, '')) = 'completed'
  AND history_row.changed_at >= now() - interval '30 days'
GROUP BY 1
ORDER BY 1 DESC;

SELECT
  (target_row.completed_at AT TIME ZONE 'Asia/Kolkata')::date AS business_date,
  COUNT(*) AS completed_spreadsheet_targets
FROM public.allocated_targets target_row
WHERE target_row.is_completed = true
  AND target_row.completed_at IS NOT NULL
  AND target_row.completed_at >= now() - interval '30 days'
GROUP BY 1
ORDER BY 1 DESC;

SELECT
  policyname,
  cmd,
  roles,
  qual,
  with_check
FROM pg_policies
WHERE schemaname = 'public' AND tablename = 'call_logs'
ORDER BY policyname;

-- Continue only when every required table/column is PRESENT.
-- It is normal for get_team_kpi_daily_v4 to be absent before migration 029.
