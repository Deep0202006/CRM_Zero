#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path


def main() -> int:
    parser = argparse.ArgumentParser(description="Rollback the approved ZeroData Team KPI overlay.")
    parser.add_argument("backup_root", type=Path)
    args = parser.parse_args()

    backup_root = args.backup_root.resolve()
    manifest = json.loads((backup_root / "backup-manifest.json").read_text(encoding="utf-8-sig"))
    project_root = Path(manifest["projectRoot"])

    for entry in manifest["files"]:
        relative = Path(entry["path"])
        destination = project_root / relative
        if entry["existedBefore"]:
            source = backup_root / relative
            if not source.is_file():
                raise SystemExit(f"Missing backup file: {relative}")
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source, destination)
        elif destination.exists():
            destination.unlink()

    print("TEAM KPI OVERLAY ROLLED BACK")
    print(f"Project: {project_root}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
