# ZeroData Team KPI — Safe Deployment Runbook

## Release order

1. Install the approved project overlay on a feature branch.
2. Run repository verification.
3. Back up Supabase.
4. Run the manual precheck SQL.
5. Apply migration 029 once.
6. Run verification SQL.
7. Deploy the feature branch to Vercel Preview.
8. Perform admin, ordinary-user, source-count, and live-update tests.
9. Ask team members to open the updated CRM once while online.
10. Recheck historical and current dates.
11. Merge to production only after all checks pass.

## Repository verification

Run:

```powershell
npm ci
npm run lint
npm test -- --runInBand
npm run build
git diff --check
```

Do not suppress failures, update tests blindly, or add a new dependency.

## Manual Supabase execution

Open the Supabase project used by the production Vercel environment.

Run in separate SQL Editor tabs:

1. `MANUAL_SUPABASE/01_PRECHECK_READ_ONLY.sql`
2. `MANUAL_SUPABASE/02_APPLY_TEAM_KPI_029.sql` — once only
3. `MANUAL_SUPABASE/03_VERIFY_READ_ONLY.sql`

Stop when a required table or column is reported missing. Do not run random fragments of the migration after an error.

When the application reports a PostgREST function/schema-cache error after successful migration execution, run separately:

```sql
NOTIFY pgrst, 'reload schema';
```

## Preview smoke test

Use one genuine admin and one ordinary account.

Verify:

- `/api/team-kpi?date=<today-IST>` returns JSON and HTTP 200 for admin.
- The response header `X-Team-KPI-Source` is `database-rpc-v4` or the controlled server fallback.
- Verification SQL returns no legacy `team_kpi_*_event` capture triggers and shows `team_work_events` absent from Realtime publication.
- Active users are returned whether `users.is_active` is stored as integer or Boolean.
- Ordinary user receives HTTP 403.
- All active users appear, including a zero-work user.
- Today and at least three retained past dates load.
- Calls match real `call_logs` records and synthetic stage notes are excluded.
- Resolved queries are credited to the resolver.
- Completed mappings are credited to the completing user.
- Completed tasks and spreadsheet targets are counted once.
- Total work equals the four visible components.
- A new work record causes one debounced refresh or appears within the 30-second fallback.
- Refresh and logout/login preserve confirmed values.
- No console, hydration, network, or Realtime error remains.

## Legacy local synchronization

After production deployment, every employee who used Call Activity before this repair should:

1. Open the latest CRM in the same browser/profile where work was logged.
2. Sign in.
3. Remain online until synchronization finishes.
4. Refresh once.

The repaired client identifies legacy `EXCEL::...` call/task payloads, converts them to the valid server shape, and retries them idempotently. Records on a device that never reconnects cannot be read centrally.

## Production monitoring

For the first 48 hours:

- Check API status and `X-Team-KPI-Source`.
- Check the sync queue for dead-letter errors.
- Compare one user/day against raw source counts.
- Confirm Realtime does not create duplicate requests.
- Do not edit migration 029 after application. Use a new forward migration for later database changes.
