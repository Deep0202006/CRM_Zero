#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import json
import shutil
from datetime import datetime, timezone
from pathlib import Path


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser(description="Install the approved ZeroData Team KPI overlay.")
    parser.add_argument("project_root", type=Path)
    args = parser.parse_args()

    package_root = Path(__file__).resolve().parent
    project_root = args.project_root.resolve()
    overlay_root = package_root / "project-overlay"
    manifest_path = package_root / "PATCH_MANIFEST.json"

    if not (project_root / "package.json").is_file():
        raise SystemExit(f"Not a ZeroData project root: {project_root}")
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))

    timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    backup_root = project_root.parent / f"CRM_Zero_team_kpi_backup_{timestamp}"
    backup_root.mkdir(parents=True, exist_ok=False)
    backup_entries: list[dict[str, object]] = []

    for entry in manifest["files"]:
        relative = Path(entry["path"])
        if relative.is_absolute() or ".." in relative.parts:
            raise SystemExit(f"Unsafe manifest path: {relative}")
        source = overlay_root / relative
        destination = project_root / relative
        if not source.is_file():
            raise SystemExit(f"Missing approved source: {relative}")
        if sha256(source) != entry["sha256"]:
            raise SystemExit(f"Package hash mismatch: {relative}")

        existed = destination.is_file()
        if existed:
            backup = backup_root / relative
            backup.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(destination, backup)
        backup_entries.append({"path": relative.as_posix(), "existedBefore": existed})

    (backup_root / "backup-manifest.json").write_text(
        json.dumps(
            {
                "projectRoot": str(project_root),
                "createdAt": datetime.now(timezone.utc).isoformat(),
                "files": backup_entries,
            },
            indent=2,
        ),
        encoding="utf-8",
    )

    for entry in manifest["files"]:
        relative = Path(entry["path"])
        source = overlay_root / relative
        destination = project_root / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, destination)
        if sha256(destination) != entry["sha256"]:
            raise SystemExit(f"Installed file verification failed: {relative}")

    print("APPROVED TEAM KPI OVERLAY INSTALLED")
    print(f"Files installed: {len(manifest['files'])}")
    print(f"Rollback backup: {backup_root}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
