param(
  [Parameter(Mandatory = $true)]
  [string]$BackupRoot
)

$ErrorActionPreference = "Stop"
$manifestPath = Join-Path $BackupRoot "backup-manifest.json"
if (-not (Test-Path $manifestPath)) { throw "Missing backup-manifest.json in $BackupRoot" }
$manifest = Get-Content $manifestPath -Raw | ConvertFrom-Json
$projectRoot = [string]$manifest.projectRoot

foreach ($entry in $manifest.files) {
  $relativePath = [string]$entry.path
  $destinationPath = Join-Path $projectRoot $relativePath
  if ([bool]$entry.existedBefore) {
    $backupPath = Join-Path $BackupRoot $relativePath
    if (-not (Test-Path $backupPath)) { throw "Missing backup file: $relativePath" }
    New-Item -ItemType Directory -Force -Path (Split-Path $destinationPath -Parent) | Out-Null
    Copy-Item $backupPath $destinationPath -Force
  } elseif (Test-Path $destinationPath) {
    Remove-Item $destinationPath -Force
  }
}

Write-Host "TEAM KPI OVERLAY ROLLED BACK" -ForegroundColor Yellow
Write-Host "Project: $projectRoot"
