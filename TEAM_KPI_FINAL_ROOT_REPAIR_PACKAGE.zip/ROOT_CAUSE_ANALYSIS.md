# ZeroData Team KPI — Principal Architecture Root-Cause Analysis

## Product goal

Keep the existing Team KPI page unchanged while reliably showing, for every active user and every retained India business date:

- Calls
- Resolved client queries
- Completed mappings
- Completed normal tasks
- Completed spreadsheet/My Day targets
- Total completed work
- Latest activity time

## Confirmed source-level failures

### 1. Call activity was stored in an invalid database shape

The current Call Activity selector uses values shaped as:

`EXCEL::<username>::<name>`

The original page wrote that value into `call_logs.lead_id`. The database defines `lead_id` as a UUID foreign key, so those records could exist in IndexedDB while their Supabase insert repeatedly failed. Team KPI can only report server-confirmed work; local-only calls therefore remained invisible.

The same invalid reference was copied into `tasks.related_lead_id` for follow-up tasks.

### 2. Offline synchronization reported local success before remote success

The existing generic mutation flow writes IndexedDB first and starts synchronization separately. Its previous remote update logic checked only the Supabase error object, not whether any row was actually affected. It also skipped all items after five failures and had no deterministic repair for the invalid Excel-reference payload.

### 3. Empty RLS responses triggered unsafe browser-cache recovery

The previous pull-down path treated an empty remote response as proof that the server table was empty and queued every local row for re-upload. An RLS-restricted response can also be empty, so this behavior could create duplicates, failed writes, and stale-data restoration attempts.

### 4. Team KPI depended on database layers that were not proven live

Several previous implementations depended on manually deployed RPC or event-ledger migrations. The forensic package did not contain live database results, the deployed Vercel commit, or an actual `/api/team-kpi` response. A missing function, stale schema cache, deployment mismatch, or incomplete ledger could therefore produce no data.

### 5. Browser aggregation could not guarantee all-user visibility

Raw browser queries remain subject to the logged-in user’s RLS and cannot reliably read every employee’s source rows. They also create multiple schema-sensitive requests and can silently produce partial zero values.

### 6. The active-user predicate used the wrong database type

The repository defines `users.is_active` as an integer (`1`/`0`), while a prior v4 draft compared it as a Boolean. PostgreSQL cannot coalesce an integer with `true`, so the RPC could fail before returning any rows. Migration 029 now normalizes integer, Boolean, and text representations through `is_active::text` and accepts only `1`, `true`, or `t`. The server fallback uses the same normalization.

### 7. The obsolete event ledger continued adding writes and Realtime noise

Migration 028 installed capture triggers and a Realtime publication for `team_work_events`. The final KPI path reads retained source records directly, so migration 029 retires only those capture triggers and removes the ledger table from Realtime. It preserves historical ledger rows and functions for audit/rollback analysis.

## Final architecture

### Authoritative source records

Team KPI reads retained operational source records directly. It does not depend on Activity Deck, KPI snapshots, or `team_work_events`.

### Primary database boundary

Migration 029 installs `get_team_kpi_daily_v4(date)`, an admin-only, fixed-search-path `SECURITY DEFINER` function. It:

- Validates `auth.uid()` and the `admin` capability.
- Includes every active human user, including zero-work users.
- Groups timestamps using `Asia/Kolkata`.
- Counts each source record once.
- Excludes synthetic pipeline call notes.
- Uses resolver/completer attribution rather than creator attribution.
- Uses task completion history and a current-task fallback.
- Includes spreadsheet/My Day target completions.
- Supports retained historical records directly.

### Controlled server fallback

The Next.js API first calls v4 using the user’s access token. If the RPC is missing or fails and `SUPABASE_SERVICE_ROLE_KEY` is already configured on Vercel, the API verifies the user’s admin capability and performs paginated aggregation using a server-only client. The service key is never sent to the browser. Browser/RLS-limited raw aggregation is forbidden.

### Durable source synchronization

The repaired client:

- Stores Excel call identity in `client_username` and `client_name`.
- Stores `lead_id = null` for non-CRM directory clients.
- Stores no invalid Excel string in task foreign keys.
- Repairs legacy dead-letter queue payloads deterministically.
- Reconstructs missing queue entries for identifiable legacy invalid call/task rows.
- Serializes queue processing with one process-level lock.
- Verifies remote inserts and updates.
- Reconciles duplicate primary keys idempotently.
- Never restores a supposedly empty remote table from browser cache.

### Live refresh

The existing Team KPI UI remains intact. It subscribes to the actual source tables and runs one debounced API refresh. A 30-second visible-tab refresh is a lightweight fallback when Realtime is unavailable.

## Historical-data boundary

This repair displays every retained remote source record and replays recoverable local legacy call/task rows when employees open the updated CRM online.

It cannot recreate records that were:

- Permanently deleted by prior purge migrations.
- Removed from browser storage.
- Never stored in either IndexedDB or Supabase.

Those records require a verified database or device backup. Inventing them would misattribute team performance.
