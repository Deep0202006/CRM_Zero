# Team KPI Release Acceptance

## Repository

- [ ] Exactly 19 approved files installed.
- [ ] No unrelated source changed.
- [ ] `npm ci` passed.
- [ ] Lint passed.
- [ ] Jest passed.
- [ ] Next.js production build passed.
- [ ] Git diff check passed.

## Supabase

- [ ] Precheck reported all core objects PRESENT.
- [ ] Migration 029 executed once without error.
- [ ] v4 RPC exists.
- [ ] `authenticated` can execute.
- [ ] `anon` and `PUBLIC` cannot execute.
- [ ] Call client columns exist.
- [ ] `call_logs.lead_id` is nullable.
- [ ] Source indexes exist.
- [ ] Realtime source tables are present.
- [ ] Legacy `team_kpi_*_event` capture triggers are absent.
- [ ] `team_work_events` is absent from Realtime publication.
- [ ] Integer/Boolean `users.is_active` values are both handled correctly.
- [ ] Schema cache reloaded only when required.

## Team KPI behavior

- [ ] All active users appear.
- [ ] Zero-work users appear with zeros.
- [ ] Today loads.
- [ ] Retained past dates load.
- [ ] Calls match source records.
- [ ] Synthetic pipeline call notes are excluded.
- [ ] Resolved queries credit resolver.
- [ ] Mappings credit completing user.
- [ ] Task history and spreadsheet targets are counted once.
- [ ] Total equals all four metrics.
- [ ] Last activity is correct.
- [ ] New source work appears live or within 30 seconds.
- [ ] API returns explicit errors rather than a false empty page.

## Sync recovery

- [ ] A new Excel-directory call synchronizes.
- [ ] Its remote `lead_id` is null.
- [ ] Client username/name are retained.
- [ ] Follow-up task has no invalid Excel UUID reference.
- [ ] Legacy dead-letter call retries after upgrade.
- [ ] Duplicate retry creates one remote row.
- [ ] Empty RLS response does not trigger browser-cache repopulation.

## Security

- [ ] Admin can load Team KPI.
- [ ] Ordinary user receives 403.
- [ ] Service role is never exposed to browser.
- [ ] No environment file was committed.
- [ ] No RLS policy was disabled.

## Deployment

- [ ] Vercel Preview commit matches feature branch.
- [ ] Preview smoke test passed.
- [ ] Every relevant employee browser reconnected once.
- [ ] Production merge approved.
