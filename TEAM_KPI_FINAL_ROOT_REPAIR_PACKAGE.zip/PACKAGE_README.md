# ZeroData Team KPI Final Root Repair Package

This package is a surgical overlay for the exact forensic source supplied on 28 July 2026.

## Goal

Keep the current Team KPI UI unchanged while making confirmed current and retained historical work visible for every active user:

- Calls
- Resolved client queries
- Completed mappings
- Completed tasks
- Spreadsheet/My Day targets
- Total work
- Latest activity

## Install

Use `INSTALL_APPROVED_OVERLAY.py` or `INSTALL_APPROVED_OVERLAY.ps1`. The installer copies exactly the 19 paths listed in `PATCH_MANIFEST.json`, verifies SHA-256 hashes, and creates an external rollback backup.

The local LLM is not expected to write or merge code.

## Database

Run the SQL files under `MANUAL_SUPABASE/` in numeric order through the Supabase Dashboard for the project used by Vercel. Apply migration 029 once only.

## Important boundary

The repair can report all retained Supabase source records and recover identifiable legacy work still present in an employee's IndexedDB when that employee reconnects on the upgraded application. It cannot recreate records previously deleted from both Supabase and the original browser profile; those require a verified backup.

See `IMPLEMENTATION_PROMPT.md`, `ROOT_CAUSE_ANALYSIS.md`, and `DEPLOYMENT_RUNBOOK.md` before release.
