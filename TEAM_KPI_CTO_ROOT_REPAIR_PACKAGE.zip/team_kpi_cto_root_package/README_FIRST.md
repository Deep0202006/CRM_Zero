# ZeroData Team KPI CTO Root Repair

This package is an incremental repair on top of the approved Team KPI 027 API foundation.

Read `IMPLEMENTATION_PROMPT.md` first. Apply the Git patch; do not overwrite the repository.

The permanent change is migration 028, which creates an idempotent `team_work_events` ledger, backfills all retained work, captures future work through narrow triggers, and exposes one admin-only v3 KPI RPC.

Database SQL must be applied manually through Supabase SQL Editor after the read-only precheck succeeds.
