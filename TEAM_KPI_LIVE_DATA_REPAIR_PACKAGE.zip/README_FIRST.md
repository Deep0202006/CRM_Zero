# ZeroData Team KPI live-data repair

This package changes only the Team KPI data boundary, its targeted tests, and the
new Team KPI database function. It preserves the existing Team KPI page design
and does not modify calls, support, mappings, tasks, pipeline, visits, attendance,
login, or other CRM workflows.

## Required order

1. Give `IMPLEMENTATION_PROMPT.md` to the local LLM and let it apply the patch on
   a new branch.
2. Require lint, Jest, production build, and `git diff --check` to pass.
3. Manually run the three SQL files in `MANUAL_SUPABASE` through the Supabase
   Dashboard SQL Editor, in numeric order. Do not use PowerShell or Supabase CLI.
4. Test a Vercel Preview deployment with an administrator and an ordinary user.
5. Merge to production only after raw-record comparison passes.

## Historical-data limitation

The supplied repository contains destructive migrations 014 and 015 that delete
business records before 8 July 2026. Team KPI can show every retained current and
past record, but no code can reconstruct physically deleted history without a
verified external backup.
